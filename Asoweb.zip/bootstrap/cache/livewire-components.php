<?php return array (
  'amigos-view' => 'App\\Http\\Livewire\\AmigosView',
  'buscador' => 'App\\Http\\Livewire\\Buscador',
  'comentario-controller' => 'App\\Http\\Livewire\\ComentarioController',
  'compartir-controller' => 'App\\Http\\Livewire\\CompartirController',
  'enviar-solicitud' => 'App\\Http\\Livewire\\EnviarSolicitud',
  'home-controller' => 'App\\Http\\Livewire\\HomeController',
  'likes' => 'App\\Http\\Livewire\\Likes',
  'mensajes.valido' => 'App\\Http\\Livewire\\Mensajes\\Valido',
  'notificacion-mensaje' => 'App\\Http\\Livewire\\NotificacionMensaje',
  'notificaciones' => 'App\\Http\\Livewire\\Notificaciones',
  'perfil-controller' => 'App\\Http\\Livewire\\PerfilController',
  'verpublicaciones' => 'App\\Http\\Livewire\\Verpublicaciones',
);