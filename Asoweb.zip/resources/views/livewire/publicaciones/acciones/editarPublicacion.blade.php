<a href="javascript:void(0)" wire:click="editar_post({{ $publicacion->id }})">
    <li class="p-1 w-32 text-gray-600 hover:bg-cyan-900 hover:text-white">
        <div  class="py-2">Editar
        </div>

    </li>
</a>