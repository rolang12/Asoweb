<div>
    <button wire:click="enviarSolicitud" class="bg-cyan-900 text-white p-3 hover:bg-cyan-700" >Enviar Solicitud</button>
</div>
