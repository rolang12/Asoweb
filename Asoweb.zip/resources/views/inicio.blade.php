<x-app-layout>@section('title', "Inicio")
</x-app-layout>


<div>
    <livewire:home-controller />
</div>
