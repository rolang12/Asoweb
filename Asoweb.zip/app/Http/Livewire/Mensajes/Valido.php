<?php

namespace App\Http\Livewire\Mensajes;

use Livewire\Component;

class Valido extends Component
{
    public function render()
    {
        return view('livewire.mensajes.valido');
    }
}
