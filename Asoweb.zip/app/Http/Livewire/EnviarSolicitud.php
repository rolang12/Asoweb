<?php

namespace App\Http\Livewire;

use Livewire\Component;

class EnviarSolicitud extends Component
{
    public function render()
    {
        return view('livewire.enviar-solicitud');
    }

    public function enviarSolicitud()
    {
        
    }

}
