<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ComentarioController extends Component
{
    public function render()
    {
        return view('livewire.comentario-controller');
    }
}
