<?php

namespace App\Http\Services;

use App\Http\Controllers\Controller;
use App\Models\Publicaciones;

class PublicacionServices extends Controller {

    
   

}