<div>
    <?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" flex flex-col shadow rounded-md mt-8 p-5">
            <div class="my-auto  ">

                <div class="grid grid-cols-2 justify-around">

                    <div>
                        <a href="<?php echo e(route('perfil', ['id' => $publicacion->users->name])); ?> "
                            class="text-blue-800 font-bold "> <?php echo e($publicacion->users->name); ?>

                        </a>
                    </div>

                    <?php if($publicacion->users->id == Auth()->user()->id): ?>
                        <div class="text-right " x-data="{ isOpen: false }">
                            <button>
                                <i @click="isOpen = !isOpen" @keydown.escape="isOpen = false"
                                    class="hover:text-cyan-800 text-center fa-solid fa-ellipsis"></i>
                            </button>
                            <ul class="bg-gray-50 text-center right-96 border absolute border-slate-200 rounded-md shadow-lg "
                                x-show="isOpen" @click.away="isOpen = false">
                                <!-- Acciones -->

                                <?php echo $__env->make('livewire.publicaciones.acciones.editarPublicacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('livewire.publicaciones.acciones.eliminarPublicacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            </ul>

                        </div>
                    <?php endif; ?>

                </div>

                <div class="grid grid-cols-2">

                    <div class="flex justify-stretch ">
                        <span> <i class="fa-regular fa-clock pr-3 text-xs "></i></span>

                        <div class="hidden"><?php echo e($minutesDiff = $fechaActual->diffInMinutes($publicacion->created_at)); ?>

                        </div>
                        <?php switch($minutesDiff):
                            case ($minutesDiff > 1 && $minutesDiff < 2): ?>
                                <p class="my-auto text-left text-xs">Hace un momento </p>
                            <?php break; ?>

                            <?php case ($minutesDiff > 3 && $minutesDiff < 60): ?>
                                <p class="my-auto text-left text-xs">Hace
                                    <?php echo e($minutesDiff = $fechaActual->diffInMinutes($publicacion->created_at)); ?> minuto(s) </p>
                            <?php break; ?>

                            <?php case ($minutesDiff > 60 && $minutesDiff < 1440): ?>
                                <p class="my-auto text-left text-xs">Hace
                                    <?php echo e($hoursDiff = $fechaActual->diffInHours($publicacion->created_at)); ?> Hora(s) </p>
                            <?php break; ?>

                            <?php case ($minutesDiff > 1440): ?>
                                <p class="my-auto text-left text-xs">Hace
                                    <?php echo e($hoursDiff = $fechaActual->diffInDays($publicacion->created_at)); ?> Día(s) </p>
                            <?php break; ?>

                            <?php default: ?>
                                <p class="my-auto text-left text-xs">Hace
                                    <?php echo e($minutesDiff = $fechaActual->diffInMinutes($publicacion->created_at)); ?> minuto(s) </p>
                        <?php endswitch; ?>

                    </div>
                    <div class="text-right ">
                        <span
                            class="rounded-xl text-center text-xs md:text-sm px-3 md:px-9 bg-yellow-500 text-white font-semibold">
                            <?php echo e($publicacion->areas->area); ?> </span>
                    </div>
                </div>

            </div>

            <div class="my-3">
                <p> <?php echo e($publicacion->texto); ?></p>


                <?php if($publicacion->imagen != null): ?>
                    <?php if(substr($publicacion->imagen, -1) == '4'): ?>
                        <video controls src="<?php echo e(asset('storage/posts/' . $publicacion->imagen)); ?>"></video>
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/posts/' . $publicacion->imagen)); ?>" alt="imagen ejemplo"
                            class="cover" class="rounded">
                    <?php endif; ?>
                <?php endif; ?>

            </div>

            <div class="flex my-2">
                <p class="  text-center text-gray-600">
                    <?php echo e($publicacion->cantidad_likes); ?>

                </p>

            </div>

            <div class="my-auto">
                

                <div class="flex justify-around text-md text-center text-gray-600 font-semibold">

                    <div class="text-center"><i class="fa-regular fa-thumbs-up"></i></div>

                    <!-- Interacciones -->

                    

                    <?php echo $__env->make('livewire.publicaciones.interacciones.likes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('livewire.publicaciones.interacciones.comentarios', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo $__env->make('livewire.publicaciones.interacciones.compartir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                </div>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/verpublicaciones.blade.php ENDPATH**/ ?>