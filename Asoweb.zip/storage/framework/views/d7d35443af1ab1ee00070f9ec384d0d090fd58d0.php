

<div x-data="{ open: false } "  class="basis-2/5" >
    <button class="text-sm md:text-base " x-on:click="open=!open">Comentar</button>

    <div x-show="open" x-on:click.away="open = false" x-bind:class="! open ? '' : ''" class="bg-gray-50 py-2">

        <div class="">

            <?php $__empty_1 = true; $__currentLoopData = $publicacion->comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <div class="flex flex-row justify-around py-2 px-1" >
                    <div class="text-left"><?php echo e($detalle->texto); ?></div>

                    <a href="<?php echo e(route('perfil', ['id' => $detalle->users->name])); ?>"
                        class="text-right text-sm text-blue-800"><?php echo e($detalle->users->name); ?>

                    </a>
                </div>
                   

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm my-3 text-gray-500">No hay comentarios aún</p>
            <?php endif; ?>

            <div class="p-3 grid grid-cols-2">

                <input placeholder="Deja tu comentario aquí..."
                    class=" rounded-md border-gray-400 mb-3" wire:model="comentario"
                    type="text">


                <button wire:click="comentar(<?php echo e($publicacion->id); ?>)"
                    class="text-sm md:text-base rounded-lg font-semibold bg-cyan-900 text-white p-1 "
                    id="submit" type="submit">Comentar
                </button>


            </div>

        </div>
    </div>

</div><?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/publicaciones/interacciones/comentarios.blade.php ENDPATH**/ ?>