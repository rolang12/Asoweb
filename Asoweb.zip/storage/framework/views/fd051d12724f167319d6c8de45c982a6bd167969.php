<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php $__env->startSection('title', "Perfil ". $userExists[0]->name); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<div>
  
    
    <div>

        <link rel="stylesheet"
            href="https://cdn.jsdelivr.net/gh/creativetimofficial/tailwind-starter-kit/compiled-tailwind.min.css" />
    
        <body class="text-gray-800 antialiased mt-20">
    
            <main class="profile-page">
                <section class="relative block" style="height: 500px;">
                    <div class="absolute top-0 w-full h-full bg-center bg-cover"
                        style='background-image: url("https://images.unsplash.com/photo-1499336315816-097655dcfbda?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2710&amp;q=80");'>
                        <span id="blackOverlay" class="w-full h-full absolute opacity-50 bg-black"></span>
                    </div>
                    <div class="top-auto bottom-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden"
                        style="height: 70px;">
                        <svg class="absolute bottom-0 overflow-hidden" xmlns="http://www.w3.org/2000/svg"
                            preserveAspectRatio="none" version="1.1" viewBox="0 0 2560 100" x="0" y="0">
                            <polygon class="text-gray-300 fill-current" points="2560 0 2560 100 0 100"></polygon>
                        </svg>
                    </div>
                </section>
                <section class="relative py-16 bg-gray-300">
                    <div class="container mx-auto px-4">
                        <div
                            class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg -mt-64">
                            <div class="px-6">
                                <div class="flex flex-wrap justify-center">
                                    <div class="w-full lg:w-3/12 px-4 lg:order-2 flex justify-center">
                                        <div class="relative">
                                            <img class="shadow-xl rounded-full h-auto align-middle border-solid border-spacing-1 border absolute -m-16 -ml-20 lg:-ml-16"
                                                src="<?php echo e(asset('storage/' . $userExists[0]->profile_photo_path)); ?>"
                                                alt="user_profile_photo" style="max-width: 150px">
    
                                        </div>
                                    </div>
                                    <div class="w-full lg:w-4/12 px-4 lg:order-3 lg:text-right lg:self-center">
    
                                    </div>
                                    <div class="w-full lg:w-4/12 px-4 lg:order-1">
                                        <div class="flex justify-center py-4 lg:pt-4 pt-8">
                                            <div class="mr-4 p-3 text-center">
                                                <span
                                                    class="text-xl font-bold block uppercase tracking-wide text-gray-700"><?php echo e($friendsCount); ?></span><span
                                                    class="text-sm text-gray-500">Amigos</span>
                                            </div>
                                            <div class="mr-4 p-3 text-center">
                                                <span
                                                    class="text-xl font-bold block uppercase tracking-wide text-gray-700"><?php echo e($postCount); ?></span><span
                                                    class="text-sm text-gray-500">Publicaciones</span>
                                            </div>
                                            <div class="lg:mr-4 p-3 text-center">
                                                <span
                                                    class="text-xl font-bold block uppercase tracking-wide text-gray-700"><?php echo e($commentsCount); ?></span><span
                                                    class="text-sm text-gray-500">Comentarios</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center mt-12">
                                    <h3 class="text-4xl font-semibold leading-normal text-gray-800 mb-2">
                                        <?php echo e($userExists[0]->name); ?>

                                    </h3>
                                    <div class="text-sm leading-normal mt-0 mb-2 text-gray-500 font-bold uppercase">
                                        <i class="fas fa-map-marker-alt mr-2 text-lg text-gray-500"></i>
                                        Area: <?php echo e($userExists[0]->areas->area); ?>

                                    </div>
                                    <div class="mb-2 text-gray-700 mt-10">
                                        <i class="fas fa-briefcase mr-2 text-lg text-gray-500"></i>Solution Manager -
                                        Creative
                                        Tim Officer
                                    </div>
                                    <div class="mb-2 text-gray-700">
                                        <i class="fas fa-university mr-2 text-lg text-gray-500"></i>University of Computer
                                        Science
                                    </div>
                                </div>
                                <div class="mt-10 py-10 border-t border-gray-300 text-center">
                                    <div class="flex flex-wrap justify-center">
                                        <div class="w-full lg:w-9/12 px-4">
                                           
                                            <button wire:click="ejemplo" >click</button>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
    
        </body>
        <script>
            function toggleNavbar(collapseID) {
                document.getElementById(collapseID).classList.toggle("hidden");
                document.getElementById(collapseID).classList.toggle("block");
            }
        </script>
    
    
    </div>
    
</div>
<?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/perfil-controller.blade.php ENDPATH**/ ?>