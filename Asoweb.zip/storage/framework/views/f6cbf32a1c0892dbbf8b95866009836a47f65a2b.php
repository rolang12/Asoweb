<div class="grid mt-20">
 
    <div class=" ">

        <div class="mx-auto bg-red-200 text-white rounded-md" wire:offline>Estás Offline</div>

        <form wire:submit.prevent="insertar_publicacion()">

            <div class="md:flex md:flex-row grid justify-around md:justify-between items-center">

                <div class="col-span-1">
                    <input wire:model="image" accept="video/webm, video/mp4, video/avi, image/jpeg, image/jpg, image/png"
                        wire:offline.attr="disabled"
                        class="file:mr-4 text-sm file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold
                                file:bg-yellow-50 file:text-yellow-400 hover:file:bg-yellow-100"
                         type="file">
                            
                </div>

                <div class=" text-center md:mx-0 mx-10 text-sm text-white px-4 bg-yellow-400 rounded-xl p-1 ">Area:</div>

                <div class=" justify-self-center my-auto">
                    
                    <select class="border-none " wire:model='area'>
                        
                        <option selected value="1"></option>
                        
                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option class="p-2 py-4" value="<?php echo e($area->id); ?>">
                                <?php echo e($area->area); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </select>
                </div>

            </div>


            <div>
                <input wire:model='text' class="w-full ring-cyan-800 my-3 rounded-lg border-gray-100"
                    placeholder="Escribe tu publicación aquí..." type="text">
                <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-center py-3 font-bold text-red-700 error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-center py-3 text-red-700 font-bold error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-center py-3 text-red-700 font-bold error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            <div>
                <button wire:offline.attr="disabled" wire:target="insertar_publicacion"
                    wire:loading.class="from-gray-300 to-gray-200" type="submit" wire:loading.attr="disabled"
                    class="hover:bg-gradient-to-l bg-gradient-to-r from-cyan-900 to-cyan-700 w-full p-3 rounded-md font-bold text-white transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 duration-300">Publicar</button>

            </div>

           

        </form>
       
       
    </div>
    <div wire:loading wire:target="insertar_publicacion">
                
        <div class="spinner mt-4 "></div>
        
            
    </div>

</div><?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/publicaciones/crearPubicacion.blade.php ENDPATH**/ ?>