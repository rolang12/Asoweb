<div wire:ignore.self class="modal fade shadow-md" id="theModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg " role="document">
        <div class="modal-content">
            <div class="modal-header bg-dark ">
                <h5 class="modal-title  ">
                    <b>Editar publicacion</b>
                </h5>
                <h6 class="text-center text-warning" wire:loading>
                    Actualizando...
                </h6>
            </div>
            <div class="modal-body">

                
               <div class="col-sm-12 col-md-12">
                    <div class="form-group">
                        
                        <input placeholder="Edita aquí tu publicación..." wire:model.lazy="newtext" type="text" class="form-control">
                        <?php $__errorArgs = ['newtext'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger er"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            
            </div>
            <div class="modal-footer text-white ">
                <button type="button" wire:click.prevent="resetUI()" class="bg-red-600 hover:bg-red-600 p-2 close-btn rounded-lg" data-dismiss="modal" >Cerrar</button>
            

                <button type="button" wire:click.prevent="actualizar_post()" class="bg-cyan-800 hover:bg-cyan-900 p-2 rounded-lg close-modal">Actualizar</button>

                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/modal.blade.php ENDPATH**/ ?>