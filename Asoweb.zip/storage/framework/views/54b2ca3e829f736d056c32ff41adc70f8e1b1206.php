<!-- Notificaciones Pusher Scripts-->


<div x-data="{ open: false }">

   <style>
   </style>

    <button x-on:click="open=!open">
        <i class="fa-solid fa-earth-americas text-white hover:text-gray-200 text-lg"> </i>
        <?php if($notificaciones->count() > 0): ?>
            <span class="w-4 h-4 text-xs absolute rounded-full bg-red-600 text-white"><?php echo e($notificaciones->count()); ?></span>
        <?php endif; ?>
    </button>

    <div class="bg-red-500" x-show="open" x-on:click.away="open = false">
        <ul class="absolute text-sm  rounded-md right-40  w-80 top-11 bg-white">
            <li class="bg-gray-50 text-gray-400 text-left py-1  px-1" ><div>Notificaciones</div></li>
            <hr>
            <?php $__empty_1 = true; $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <li  class="bg-white text-left  px-5 py-2 shadow-md hover:bg-cyan-100 text-gray-800">
                        
                        
                            <div class="flex cursor-pointer justify-evenly">
                                <div> <img class="w-10 h-10 rounded-full object-cover" src="<?php echo e(asset('storage/'.$notificacion->users->profile_photo_path)); ?>" alt="img"></div>
                                <div class="inline-flex ml-2 items-center font-semibold "><?php echo e($notificacion->tipo_mensaje); ?></div>
                            </div>
                        
                    </li>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <li class="bg-white text-left px-5 py-2 shadow-md  text-gray-800">
                    <small class="">No hay mensajes</small>
                </li>
            <?php endif; ?>
        </ul>

    </div>

</div>


<?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/notificaciones.blade.php ENDPATH**/ ?>