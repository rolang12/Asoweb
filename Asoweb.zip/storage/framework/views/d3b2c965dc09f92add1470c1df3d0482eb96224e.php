<a href="javascript:void(0)" onclick="Confirm('<?php echo e($publicacion->id); ?>')">
    <li  class="p-1 w-32 text-gray-600 hover:bg-cyan-900 hover:text-white">
        <div 
            class="py-2 ">Eliminar
        </div>
    </li>
</a><?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/publicaciones/acciones/eliminarPublicacion.blade.php ENDPATH**/ ?>