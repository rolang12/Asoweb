<div>

    <div wire:ignore.self class="modal fade " id="theModal" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg " role="document">
                <div class="modal-content">
                    <div class="modal-header bg-dark ">
                        <h5 class="modal-title text-white ">
                            <b>titulo
                        </h5>
                        <h6 class="text-center text-warning" wire:loading>
                            Please Wait
                        </h6>
                    </div>
                    <div class="modal-body">
                    
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <span class="fas fa-edit"></span>
                                        </span>
                                    </div>
                                    <input type="text" wire:model.lazy="texto" class="form-control">
                                    <!-- cuando se da click afuera lo que escrib+i se envia al backend -->
                                </div>

                                <?php $__errorArgs = ['texto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger er"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-12 mt-3">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input form-control" wire:model="image"
                                        accept="image/png, image/gif, image/jpeg">
                                    <label class="custom-file-label">Image <?php echo e($image); ?></label>
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger er"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                    
                        <div class="modal-footer">
                            <button type="button" wire:click.prevent="resetUI()" class="btn btn-dark close-btn text-info" data-dismiss="modal" >Close</button>


                            <button type="button" wire:click.prevent="actualizar_post()" class="btn btn-dark close-modal">Update</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/editarPost/modal.blade.php ENDPATH**/ ?>