
<div class="md:flex grid grid-cols-1 mx-5 ">
  
    <!-- Empieza la seccion de noticias -->
        <div class="md:w-2/6  " >
            <div class="">AAAA</div>
        </div>
    <!-- Termina seccion noticias -->

    <!-- Empieza la seccion de publicaciones -->
        <div class=" md:w-3/6">

            <!-- Empieza la seccion de publicar -->
                <?php echo $__env->make('livewire.publicaciones.crearPubicacion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Termina la seccion de publicar -->        

            <!-- Alertas -->
                <?php echo $__env->make('livewire.alertas.publicado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('livewire.alertas.actualizado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('livewire.alertas.eliminado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Fin Alertas -->

            <!-- Empieza la seccion de ver publicaciones -->
                <?php echo $__env->yieldContent('ver'); ?>
                <?php echo $__env->make('livewire.publicaciones.verPublicaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <!-- Termina la seccion de publicaciones -->
            <?php echo $__env->make('livewire.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    <!-- Termina la seccion de publicaciones -->

    <!-- Empieza la seccion de amigos -->
        <div class="md:w-1/6 invisible md:visible ml-10" > 
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('amigos-view', [])->html();
} elseif ($_instance->childHasBeenRendered('l3221578770-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3221578770-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3221578770-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3221578770-0');
} else {
    $response = \Livewire\Livewire::mount('amigos-view', []);
    $html = $response->html();
    $_instance->logRenderedChild('l3221578770-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    <!-- Termina la seccion de amigos -->

    <script>

        document.addEventListener('DOMContentLoaded', function() {
            window.livewire.on('show-modal', msg => {
                $('#theModal').modal('show')
            });
    
        
            window.livewire.on('category-updated', msg => {
                $('#theModal').modal('hide')
            });
    
        });
    
    
        function Confirm(publicacion) {
    
           
    
            swal({
                title: 'Eliminar Publicación',
                text: '¿Segur@ que deseas eliminar la publicación?',
                type: 'warning',
                showCancelButton: true,
                cancelButtonText: 'Cerrar',
                cancelButtonColor: '#fff',
                confirmButtonColor: '#DC2626',
                confirmButtonText: 'Aceptar'
            }).then(function(result) {
                if (result.value) {
                    window.livewire.emit('deleteRow', publicacion)
                    swal.close()
                }
            })
            }
    </script>

</div>
<?php /**PATH C:\laragon\www\Asoweb\resources\views/livewire/home-controller.blade.php ENDPATH**/ ?>